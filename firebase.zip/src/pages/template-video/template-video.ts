import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CustomizationPage } from '../customization/customization';

/**
 * Generated class for the TemplateVideoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-template-video',
  templateUrl: 'template-video.html',
})
export class TemplateVideoPage {

  customizePage= CustomizationPage

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TemplateVideoPage');
  }

  onClickCustomization(){
    this.navCtrl.push(this.customizePage);
  }

}
