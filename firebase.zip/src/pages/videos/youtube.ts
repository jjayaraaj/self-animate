import { Component } from '@angular/core';
import {  NavController, NavParams } from 'ionic-angular';





@Component({
  selector: 'page-youtube',
  template: `
  <ion-header >

  <ion-navbar color="primary">
    <ion-title text-center>Youtube Video</ion-title>
  </ion-navbar>

    </ion-header>
    <ion-content>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/eTIEAHmAYhk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </ion-content>
  `
})

export class Youtube{
    constructor(public navCtrl: NavController, public navParams: NavParams) {
    }
}